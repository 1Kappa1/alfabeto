# Pangramma
## *(Alfabeto...)*

Esistono frasi molto diffuse in ambito ICT, che sembrano un po’ strane e non si capisce bene come mai vengano usate in modo così frequente.

Ad esempio: “The quick brown fox jumps over the lazy dog”

In realtà sono frasi nate tanto tempo fa, quando ancora i font venivano disegnati a mano ed era necessario dotarsi di frasi che potessero dare una verifica visiva della qualità del font.

Sono i cosidetti *pangrammi* e hanno la caratteristica di contenere tutte le lettere dell’alfabeto (anche ripetute…)

Data una frase, il programma da realizzare dovrà verificare se risulta un pangramma.
