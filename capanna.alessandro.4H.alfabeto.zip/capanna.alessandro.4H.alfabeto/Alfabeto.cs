﻿using System;
// write in 2019 by maurizio.conti@fablabromagna.org

public static class Alfabeto
{
    public static bool Verifica(string input)
    {
        bool ritorno;
        int cntfinale=0;
        int cnt=0;
        string alfabeto = "a"+"b"+"c"+"d"+"e"+"f"+"g"+"h"+"i"+"l"+"m"+"n"+"o"+"p"+"q"+"r"+"s"+"t"+"u"+"v"+"z";
        for(int i=0; i<alfabeto.Length; i++)
        {
            for(int a=0; a<input.Length; a++)
            {
                if(alfabeto[i] == input[a])
                {
                        cnt++;
                }
            }
            if(cnt>0)
            {
                cntfinale +=1;
                
            }
        }

        if(cntfinale==21)
            {
                ritorno=true;
            }
            else
            {
                ritorno=false;
            }

        return ritorno;
    }
}
